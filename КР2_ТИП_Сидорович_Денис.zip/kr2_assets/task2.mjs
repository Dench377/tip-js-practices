import { isValidTaskList, loadTasks, saveTasks, STORAGE_VERSION } from "../pr4/src/task-storage.js";

// Эмуляция объекта Storage в памяти
class MemoryStorage {
  constructor() {
    this.map = new Map();
  }
  getItem(key) {
    return this.map.has(key) ? this.map.get(key) : null;
  }
  setItem(key, value) {
    this.map.set(key, String(value));
  }
  removeItem(key) {
    this.map.delete(key);
  }
}

const storage = new MemoryStorage();
const KEY = "tip-js-kr2-tasks";
const fallbackTasks = [
  { id: 1, title: "Изучить функции", completed: true, priority: "medium" },
  { id: 4, title: "Подготовить модель задач", completed: false, priority: "high" },
];

console.log("=== ЗАДАНИЕ 2: ЛОКАЛЬНОЕ ВЕРСИОНИРОВАННОЕ ХРАНИЛИЩЕ ===");

// 1. Успешное сохранение и загрузка валидного набора (версия 1)
const initialTasks = [
  { id: 1, title: "Изучить функции", completed: true, priority: "medium" },
  { id: 4, title: "Подготовить модель задач", completed: false, priority: "high" },
];
const saveRes = saveTasks(storage, KEY, initialTasks);
console.log("\n1. Сохранение валидного списка:");
console.log("saveTasks ok:", saveRes.ok);
console.log("Сохранённая JSON-строка:", storage.getItem(KEY));

const loadRes1 = loadTasks(storage, KEY, fallbackTasks);
console.log("loadTasks ok:", loadRes1.ok, "source:", loadRes1.source);
console.log("Загружено задач:", loadRes1.tasks.length);
console.log("Идентификаторы:", loadRes1.tasks.map((t) => t.id));

// 2. Обработка повреждённого JSON в хранилище
storage.setItem(KEY, "{broken json syntax: missing quotes");
console.log("\n2. Обработка повреждённого JSON в хранилище:");
const loadRes2 = loadTasks(storage, KEY, fallbackTasks);
console.log("loadTasks ok:", loadRes2.ok, "source:", loadRes2.source);
console.log("Сообщение об ошибке:", loadRes2.error);
console.log("Возвращены резервные задачи:", loadRes2.tasks.length);
console.log("Повреждённая запись удалена из storage:", storage.getItem(KEY) === null);

// 3. Несовместимая версия структуры (version: 99)
storage.setItem(KEY, JSON.stringify({ version: 99, tasks: initialTasks }));
console.log("\n3. Обработка несовместимой версии хранилища (version: 99):");
const loadRes3 = loadTasks(storage, KEY, fallbackTasks);
console.log("loadTasks ok:", loadRes3.ok, "source:", loadRes3.source);
console.log("Сообщение об ошибке:", loadRes3.error);
console.log("Возвращены fallback-задачи:", loadRes3.tasks.length);
