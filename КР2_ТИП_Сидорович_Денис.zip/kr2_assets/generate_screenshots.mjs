import { spawn } from "node:child_process";
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import { pathToFileURL } from "node:url";

const edgePath = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";

async function fetchJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let data = "";
      res.on("data", (chunk) => { data += chunk; });
      res.on("end", () => resolve(JSON.parse(data)));
    }).on("error", reject);
  });
}

async function captureStaticHtml(htmlPath, outPng) {
  const fileUrl = pathToFileURL(path.resolve(htmlPath)).href;
  const edgeProc = spawn(edgePath, [
    "--headless",
    "--disable-gpu",
    "--window-size=1080,720",
    `--screenshot=${path.resolve(outPng)}`,
    fileUrl,
  ]);
  await new Promise((res) => edgeProc.on("close", res));
  console.log(`Saved ${outPng}`);
}

async function captureTask4() {
  // Start server
  const serverProc = spawn("node", ["tools/start.mjs"], { cwd: "c:/Users/denis/Documents/mirea_works/tech_of_undust/pr6" });
  await new Promise((r) => setTimeout(r, 1500));

  const edgeProc = spawn(edgePath, [
    "--headless",
    "--disable-gpu",
    "--remote-debugging-port=9226",
    "--window-size=1200,900",
    "http://127.0.0.1:5506/?dataset=variant",
  ]);

  let wsUrl = null;
  for (let i = 0; i < 30; i++) {
    try {
      const list = await fetchJson("http://127.0.0.1:9226/json");
      const target = list.find((t) => t.url.includes("dataset=variant"));
      if (target && target.webSocketDebuggerUrl) {
        wsUrl = target.webSocketDebuggerUrl;
        break;
      }
    } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }

  const ws = new WebSocket(wsUrl);
  let id = 1;

  await new Promise((resolve) => {
    ws.onopen = () => {
      // Wait for app ready
      const checkTimer = setInterval(() => {
        ws.send(JSON.stringify({
          id: id++,
          method: "Runtime.evaluate",
          params: { expression: "document.querySelector('#list-state')?.dataset.kind" },
        }));
      }, 400);

      let step = 0;
      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        const val = msg?.result?.result?.value;

        if (step === 0 && val === "ready") {
          step = 1;
          clearInterval(checkTimer);
          // Fill form and submit
          ws.send(JSON.stringify({
            id: id++,
            method: "Runtime.evaluate",
            params: {
              expression: `(() => {
                const title = document.querySelector('#task-title');
                const priority = document.querySelector('#task-priority');
                const cat = document.querySelector('#task-category');
                title.value = 'Проверить клиентские сценарии ПР6';
                priority.value = 'high';
                cat.value = '2';
                title.dispatchEvent(new Event('input', { bubbles: true }));
                priority.dispatchEvent(new Event('change', { bubbles: true }));
                cat.dispatchEvent(new Event('change', { bubbles: true }));
                document.querySelector('#task-form').requestSubmit();
              })()`,
            },
          }));

          // Poll for task 35
          const waitTask = setInterval(() => {
            ws.send(JSON.stringify({
              id: id++,
              method: "Runtime.evaluate",
              params: { expression: "Boolean(document.querySelector('[data-task-id=\"35\"]'))" },
            }));
          }, 300);

          ws.onmessage = (ev) => {
            const m = JSON.parse(ev.data);
            if (m.result?.result?.value === true) {
              clearInterval(waitTask);
              // Wait 300ms and capture screenshot
              setTimeout(() => {
                ws.send(JSON.stringify({ id: 777, method: "Page.captureScreenshot", params: { format: "png" } }));
              }, 300);
            }
            if (m.id === 777 && m.result?.data) {
              fs.writeFileSync("c:/Users/denis/Documents/mirea_works/tech_of_undust/kr2_assets/screenshot_task4.png", Buffer.from(m.result.data, "base64"));
              console.log("Saved screenshot_task4.png");
              ws.close();
              edgeProc.kill();
              serverProc.kill();
              resolve();
            }
          };
        }
      };
    };
  });
}

async function runAll() {
  await captureStaticHtml("c:/Users/denis/Documents/mirea_works/tech_of_undust/kr2_assets/task1.html", "c:/Users/denis/Documents/mirea_works/tech_of_undust/kr2_assets/screenshot_task1.png");
  await captureStaticHtml("c:/Users/denis/Documents/mirea_works/tech_of_undust/kr2_assets/task2.html", "c:/Users/denis/Documents/mirea_works/tech_of_undust/kr2_assets/screenshot_task2.png");
  await captureStaticHtml("c:/Users/denis/Documents/mirea_works/tech_of_undust/kr2_assets/task3.html", "c:/Users/denis/Documents/mirea_works/tech_of_undust/kr2_assets/screenshot_task3.png");
  await captureTask4();
  console.log("ALL 4 SCREENSHOTS CAPTURED SUCCESSFULLY!");
}

runAll();
