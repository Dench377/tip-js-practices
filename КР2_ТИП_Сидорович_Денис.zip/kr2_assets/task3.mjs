import { createApiServer } from "../pr6/api/server.mjs";
import { ApiError, createApiClient } from "../pr6/src/api-client.js";

async function listen(server) {
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  return `http://127.0.0.1:${server.address().port}/api`;
}

const server = createApiServer();
const baseUrl = await listen(server);
const client = createApiClient({ baseUrl, timeoutMs: 3000 });

console.log("=== ЗАДАНИЕ 3: HTTP-КЛИЕНТ И КЛАССИФИКАЦИЯ ОШИБОК ===");

try {
  // 1. Успешный запрос с query-параметрами
  console.log("\n1. Успешный запрос GET /tasks?completed=false:");
  const resSuccess = await client.requestJson("/tasks", { query: { completed: false } });
  console.log("Статус: 200 OK");
  console.log("Получено задач:", resSuccess.data.length);
  console.log("ID первых трёх задач:", resSuccess.data.slice(0, 3).map((t) => t.id));

  // 2. Прерывание по таймауту
  console.log("\n2. Проверка тайм-аута (AbortSignal.timeout):");
  try {
    await client.requestJson("/debug/delay", { query: { ms: 150 }, timeoutMs: 15 });
  } catch (err) {
    console.log("Перехвачена ошибка:", err.name);
    console.log("Вид ошибки (kind):", err.kind);
    console.log("Сообщение:", err.message);
  }

  // 3. Серверная ошибка HTTP 404 со структурированным телом
  console.log("\n3. Проверка HTTP 404 (GET /tasks/999):");
  try {
    await client.requestJson("/tasks/999");
  } catch (err) {
    console.log("Перехвачена ошибка:", err.name);
    console.log("Вид ошибки (kind):", err.kind);
    console.log("HTTP-статус:", err.status);
    console.log("Код ошибки контракта (code):", err.code);
    console.log("Детали (details):", err.details);
  }

  // 4. Успешный ответ 204 No Content
  console.log("\n4. Проверка ответа 204 No Content (DELETE /tasks/1):");
  const res204 = await client.requestJson("/tasks/1", { method: "DELETE" });
  console.log("Результат вызова DELETE:", res204); // null
} finally {
  server.close();
}
