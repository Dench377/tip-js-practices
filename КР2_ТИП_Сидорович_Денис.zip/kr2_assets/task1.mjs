import { validateTaskDraft } from "../pr6/src/form-validation.js";

const categories = [
  { id: 1, name: "Учёба" },
  { id: 2, name: "Проект" },
  { id: 3, name: "Организация" },
];

console.log("=== ЗАДАНИЕ 1: ВАЛИДАЦИЯ И НОРМАЛИЗАЦИЯ ДАННЫХ ФОРМЫ ===");

// 1. Корректные входные данные с лишними пробелами и числом в виде строки
const draftValid = {
  title: "  Подготовить учебный релиз  ",
  priority: "high",
  categoryId: "2",
};
const resValid = validateTaskDraft(draftValid, categories);
console.log("\n1. Проверка корректных данных:");
console.log("Входные данные:", draftValid);
console.log("Результат valid:", resValid.valid);
console.log("Нормализованные данные:", resValid.value);
console.log("Ошибки:", resValid.errors);

// 2. Полностью некорректные входные данные
const draftInvalid = {
  title: "   ",
  priority: "urgent",
  categoryId: "99",
};
const resInvalid = validateTaskDraft(draftInvalid, categories);
console.log("\n2. Проверка некорректных данных:");
console.log("Входные данные:", draftInvalid);
console.log("Результат valid:", resInvalid.valid);
console.log("Ошибки по полям:", resInvalid.errors);

// 3. Граничные значения длины названия (1, 100 и 101 символ)
console.log("\n3. Проверка граничных значений длины названия:");
const resMin = validateTaskDraft({ title: "A", priority: "low", categoryId: 1 }, categories);
console.log("Длина 1 символ ('A'): valid =", resMin.valid, "errors =", resMin.errors);

const res100 = validateTaskDraft({ title: "X".repeat(100), priority: "medium", categoryId: 1 }, categories);
console.log("Длина 100 символов: valid =", res100.valid, "errors =", res100.errors);

const res101 = validateTaskDraft({ title: "Y".repeat(101), priority: "medium", categoryId: 1 }, categories);
console.log("Длина 101 символ: valid =", res101.valid, "errors =", res101.errors);
