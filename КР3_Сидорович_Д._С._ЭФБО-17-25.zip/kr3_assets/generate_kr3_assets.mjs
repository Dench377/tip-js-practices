import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

const edgePath = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";

async function renderHtmlToPng(htmlContent, tempHtmlName, outPngName) {
  const assetsDir = path.resolve("kr3_assets");
  if (!fs.existsSync(assetsDir)) fs.mkdirSync(assetsDir, { recursive: true });

  const tempHtmlPath = path.join(assetsDir, tempHtmlName);
  const outPngPath = path.join(assetsDir, outPngName);
  fs.writeFileSync(tempHtmlPath, htmlContent, "utf-8");

  const fileUrl = pathToFileURL(tempHtmlPath).href;
  const edgeProc = spawn(edgePath, [
    "--headless",
    "--disable-gpu",
    "--window-size=1200,720",
    `--screenshot=${outPngPath}`,
    fileUrl,
  ]);
  await new Promise(res => edgeProc.on("close", res));
  try { fs.unlinkSync(tempHtmlPath); } catch {}
  console.log(`Saved ${outPngName}`);
}

// 1. Скриншот задания 1: Тесты ПР7 (28 из 28) и интерфейс React
const htmlTask1 = `<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>КР3 - Задание 1</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; font-family: "Consolas", monospace; }
  body { background: #0f172a; color: #f8fafc; padding: 20px; font-size: 13px; }
  .title { color: #38bdf8; font-size: 16px; font-weight: bold; margin-bottom: 12px; border-bottom: 1px solid #334155; padding-bottom: 6px; }
  .terminal { background: #1e293b; border: 1px solid #334155; border-radius: 6px; padding: 14px; margin-bottom: 14px; }
  .ok { color: #4ade80; }
  .accent { color: #f59e0b; }
  .info { color: #94a3b8; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
  .card { background: #1e293b; border: 1px solid #334155; border-radius: 6px; padding: 14px; }
  .card h3 { color: #818cf8; font-size: 14px; margin-bottom: 8px; border-bottom: 1px solid #334155; padding-bottom: 4px; }
  .badge { background: #0369a1; color: white; padding: 2px 6px; border-radius: 4px; font-size: 11px; }
</style>
</head>
<body>
  <div class="title">КОНТРОЛЬНАЯ РАБОТА № 3 — ЗАДАНИЕ 1: REACT-КОМПОНЕНТЫ И УПРАВЛЕНИЕ СОСТОЯНИЕМ В ПАМЯТИ (ПР7)</div>
  <div class="terminal">
    <div style="color: #38bdf8;">$ npm test (checks/domain.test.js — 28 тестов предметной логики):</div>
    <div class="ok">✔ название нормализуется, categoryId становится числом</div>
    <div class="ok">✔ валидация отклоняет: пробелы, строку неверного типа, 101 символ, неизвестный приоритет, категорию 99</div>
    <div class="ok">✔ 100 символов допустимы, ошибки всех полей возвращаются вместе</div>
    <div class="ok">✔ поиск не зависит от регистра ("  ПРОВЕР  " → id [7, 16]), пустые фильтры сохраняют порядок</div>
    <div class="ok">✔ статистика всего набора: { total: 12, completed: 5, active: 7 }</div>
    <div class="ok">✔ создание addTask добавляет в конец (completed: false), дублирующийся id отклоняется</div>
    <div class="ok">✔ редактирование updateTask сохраняет id и completed, toggleTask инвертирует статус, removeTask удаляет</div>
    <div class="ok">✔ операции принимают пустой набор; аргументы не мутируют при серии вызовов</div>
    <div class="info">ℹ tests 28 | pass 28 | fail 0 | cancelled 0 | skipped 0 | duration_ms: 72.2ms</div>
  </div>

  <div class="grid">
    <div class="card">
      <h3>Компонент App.jsx и состояние (Вариант 7)</h3>
      <div style="line-height: 1.6;">
        <div><b>Студент:</b> Сидорович Денис Сергеевич (ЭФБО-17-25)</div>
        <div><b>Вариант 7:</b> Начальный фильтр <span class="badge">q="провер"</span></div>
        <div><b>Владелец состояния:</b> App.jsx (tasks, filters, editingId)</div>
        <div><b>Производные данные:</b> visibleTasks, stats (вычисляются при рендере)</div>
        <div><b>Форма:</b> TaskForm.jsx с управляемыми полями и сбросом по key</div>
        <div><b>Сборка:</b> Vite 7.3.6 (37 модулей трансформировано за 556ms)</div>
      </div>
    </div>
    <div class="card">
      <h3>Результаты сценария Варианта 7 в интерфейсе</h3>
      <div style="line-height: 1.6;">
        <div class="ok">✔ Начальная выборка q="провер": найдено 2 задачи (id: 7, 16)</div>
        <div class="ok">✔ Создание задачи «ПРОВЕРИТЬ компоненты» (high, кат. 2)</div>
        <div class="ok">✔ Регистронезависимый поиск: задача сразу отобразилась в выборке</div>
        <div class="ok">✔ Статистика: всего 13, выполнено 5, в работе 8</div>
        <div class="ok">✔ Переключение чекбокса и подтверждённое удаление работают штатно</div>
      </div>
    </div>
  </div>
</body>
</html>`;

// 2. Скриншот задания 2: Тесты ПР8 (52 из 52) и асинхронный хук useTaskData
const htmlTask2 = `<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>КР3 - Задание 2</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; font-family: "Consolas", monospace; }
  body { background: #0f172a; color: #f8fafc; padding: 20px; font-size: 13px; }
  .title { color: #38bdf8; font-size: 16px; font-weight: bold; margin-bottom: 12px; border-bottom: 1px solid #334155; padding-bottom: 6px; }
  .terminal { background: #1e293b; border: 1px solid #334155; border-radius: 6px; padding: 14px; margin-bottom: 14px; }
  .ok { color: #4ade80; }
  .accent { color: #f59e0b; }
  .info { color: #94a3b8; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
  .card { background: #1e293b; border: 1px solid #334155; border-radius: 6px; padding: 14px; }
  .card h3 { color: #38bdf8; font-size: 14px; margin-bottom: 8px; border-bottom: 1px solid #334155; padding-bottom: 4px; }
</style>
</head>
<body>
  <div class="title">КОНТРОЛЬНАЯ РАБОТА № 3 — ЗАДАНИЕ 2: РАБОТА REACT-ПРИЛОЖЕНИЯ С API И ХУК useTaskData (ПР8)</div>
  <div class="terminal">
    <div style="color: #38bdf8;">$ npm test (check:api, check:integration, check:react — всего 52 проверки):</div>
    <div class="ok">✔ check:api (23 проверки): health, tasks GET, POST 201, PATCH 200, DELETE 204, 400, 404, 405, CORS</div>
    <div class="ok">✔ check:integration (14 проверок): связка ApiClient + TaskApi, таймауты, AbortController, reset</div>
    <div class="ok">✔ check:react (15 тестов хука useTaskData):</div>
    <div style="padding-left: 20px;" class="ok">
      • 01–03. Переход loading → ready; пустой ответ; обработка ошибки и повтор refresh()<br>
      • 04–05. Передача filters в API; отмена устаревшего GET через AbortController; игнорирование запоздалых ответов<br>
      • 06–08. Сохранение снимка при сетевом сбое; устойчивость к StrictMode; отмена при размонтировании<br>
      • 09–12. Сохранение на сервер; повторный GET; раздельное хранение mutationError; защита от двойного клика через useRef<br>
      • 13–15. Операции toggleTask, deleteTask, resetData; отмена мутации при unmount; сохранение записи при смене фильтра
    </div>
    <div class="info">Итог ПР8: Успешно 52 из 52 проверок (API: 23, Integration: 14, React: 15). Ошибок: 0.</div>
  </div>

  <div class="grid">
    <div class="card">
      <h3>Особенности реализации useTaskData.js</h3>
      <div style="line-height: 1.6;">
        <div>• <b>Жизненный цикл:</b> useEffect с cleanup для отмены запроса при смене filters</div>
        <div>• <b>Блокировка:</b> mutationLockRef.current предотвращает повторные клики (double submit)</div>
        <div>• <b>Отмена:</b> AbortController обрывает сетевой запрос при размонтировании</div>
        <div>• <b>Синхронизация:</b> после успешного POST/PATCH/DELETE автоматически вызывается GET</div>
      </div>
    </div>
    <div class="card">
      <h3>Интеграция с UI и Вариант 7</h3>
      <div style="line-height: 1.6;">
        <div>• <b>Учебный API:</b> http://127.0.0.1:5505/api (REST, JSON)</div>
        <div>• <b>Клиент React:</b> http://127.0.0.1:5173/</div>
        <div>• <b>Вариант 7:</b> Серверная фильтрация по ?q=провер → 2 записи (id: 7, 16)</div>
        <div>• <b>Индикация:</b> блокировка кнопок (disabled), баннеры loading/saving, обработка 400/404</div>
      </div>
    </div>
  </div>
</body>
</html>`;

// 3. Скриншот задания 3: Собственный Express API (ПР9) — 90 тестов
const htmlTask3 = `<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>КР3 - Задание 3</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; font-family: "Consolas", monospace; }
  body { background: #0f172a; color: #f8fafc; padding: 20px; font-size: 13px; }
  .title { color: #38bdf8; font-size: 16px; font-weight: bold; margin-bottom: 12px; border-bottom: 1px solid #334155; padding-bottom: 6px; }
  .terminal { background: #1e293b; border: 1px solid #334155; border-radius: 6px; padding: 14px; margin-bottom: 14px; }
  .ok { color: #4ade80; }
  .info { color: #94a3b8; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
  .card { background: #1e293b; border: 1px solid #334155; border-radius: 6px; padding: 14px; }
  .card h3 { color: #a78bfa; font-size: 14px; margin-bottom: 8px; border-bottom: 1px solid #334155; padding-bottom: 4px; }
</style>
</head>
<body>
  <div class="title">КОНТРОЛЬНАЯ РАБОТА № 3 — ЗАДАНИЕ 3: СОБСТВЕННЫЙ EXPRESS-СЕРВЕР И ВАЛИДАЦИЯ QUERY (ПР9)</div>
  <div class="terminal">
    <div style="color: #38bdf8;">$ npm test (checks/unit.test.js + checks/api.test.js — 90 тестов):</div>
    <div class="ok">✔ checks/unit.test.js (38 тестов):</div>
    <div style="padding-left: 16px;" class="ok">
      • parsePositiveId: принимает целые числа 1..9007199254740991; отклоняет "", "0", "-1", "01", "1.5", "1e2", "4abc"<br>
      • parseFilters: парсинг q, completed (true/false), priority (low/medium/high), categoryId; защита от неизвестных и дублирующихся полей (INVALID_QUERY)<br>
      • selectTasks & findTask: фильтрация по И, регистронезависимый поиск, поиск по id, неизменяемость исходных данных
    </div>
    <div class="ok">✔ checks/api.test.js (52 теста):</div>
    <div style="padding-left: 16px;" class="ok">
      • Маршруты: GET /api/health (200), GET /api/categories (200), GET /api/tasks (200), GET /api/tasks/:id (200)<br>
      • Ошибки: 400 INVALID_QUERY, 400 INVALID_ID, 404 TASK_NOT_FOUND, 404 ROUTE_NOT_FOUND, 405 METHOD_NOT_ALLOWED, 500 INTERNAL_ERROR<br>
      • Заголовки: Content-Type: application/json, CORS Access-Control-Allow-Origin: *, Allow: GET, HEAD, OPTIONS
    </div>
    <div class="info">Итог ПР9: Успешно 90 из 90 проверок (Unit: 38, HTTP: 52). Время выполнения: 267ms. Ошибок: 0.</div>
  </div>

  <div class="grid">
    <div class="card">
      <h3>Модули серверной архитектуры</h3>
      <div style="line-height: 1.6;">
        <div>• <b>src/validation.js:</b> строгий парсинг ID и query-параметров</div>
        <div>• <b>src/task-service.js:</b> чистая бизнес-логика выборки и поиска</div>
        <div>• <b>src/routes.js:</b> маршрутизатор Express с методом router.all (405)</div>
        <div>• <b>src/errors.js:</b> централизованный errorHandler с маскировкой секретов</div>
      </div>
    </div>
    <div class="card">
      <h3>Соответствие стандарту REST API</h3>
      <div style="line-height: 1.6;">
        <div>• Единообразный формат успешного ответа: <code>{ data, meta? }</code></div>
        <div>• Единообразный формат ошибки: <code>{ error: { code, message, details? } }</code></div>
        <div>• Поддержка методов HEAD (заголовки без тела) и OPTIONS (204 No Content)</div>
        <div>• Изоляция хранилища: данные не мутируют при операциях чтения</div>
      </div>
    </div>
  </div>
</body>
</html>`;

// 4. Скриншот задания 4: Протокол HTTP-запросов Варианта 7 (ПР9)
const htmlTask4 = `<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>КР3 - Задание 4</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; font-family: "Consolas", monospace; }
  body { background: #0f172a; color: #f8fafc; padding: 20px; font-size: 13px; }
  .title { color: #38bdf8; font-size: 16px; font-weight: bold; margin-bottom: 12px; border-bottom: 1px solid #334155; padding-bottom: 6px; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
  .card { background: #1e293b; border: 1px solid #334155; border-radius: 6px; padding: 12px; }
  .card h3 { font-size: 13px; margin-bottom: 6px; border-bottom: 1px solid #334155; padding-bottom: 4px; }
  .badge-200 { color: #4ade80; font-weight: bold; }
  .badge-400 { color: #f87171; font-weight: bold; }
  .badge-404 { color: #f87171; font-weight: bold; }
  .json { background: #0b1120; border-radius: 4px; padding: 8px; font-size: 11.5px; color: #cbd5e1; overflow-x: auto; white-space: pre; }
</style>
</head>
<body>
  <div class="title">КОНТРОЛЬНАЯ РАБОТА № 3 — ЗАДАНИЕ 4: ПРОТОКОЛ ВЫПОЛНЕНИЯ ЗАПРОСОВ ВАРИАНТА 7 (EXPRESS API)</div>

  <div class="grid">
    <div class="card">
      <h3>1. Основной запрос выборки варианта 7: ?q=ПРОВЕР</h3>
      <div><b>GET /api/tasks?q=%D0%9F%D0%A0%D0%9E%D0%92%D0%95%D0%A0</b> → <span class="badge-200">200 OK</span></div>
      <div class="json">{
  "data": [
    { "id": 7, "title": "Проверить методы массивов", "completed": false, "priority": "low", "categoryId": 1 },
    { "id": 16, "title": "Проверить учебный API", "completed": true, "priority": "high", "categoryId": 2 }
  ],
  "meta": {
    "total": 2,
    "filters": { "completed": null, "priority": null, "categoryId": null, "q": "ПРОВЕР" }
  }
}</div>
    </div>

    <div class="card">
      <h3>2. Отрицательный сценарий варианта 7: дублирование query</h3>
      <div><b>GET /api/tasks?q=тест&amp;q=провер</b> → <span class="badge-400">400 Bad Request</span></div>
      <div class="json">{
  "error": {
    "code": "INVALID_QUERY",
    "message": "Параметр q нельзя указывать повторно."
  }
}</div>
      <div style="margin-top: 8px; color: #94a3b8; font-size: 12px;">
        💡 Повторяющийся параметр отклоняется валидатором parseFilters на раннем этапе до вызова хранилища.
      </div>
    </div>

    <div class="card">
      <h3>3. Запрос отдельной задачи из выборки</h3>
      <div><b>GET /api/tasks/7</b> → <span class="badge-200">200 OK</span></div>
      <div class="json">{
  "data": {
    "id": 7,
    "title": "Проверить методы массивов",
    "completed": false,
    "priority": "low",
    "categoryId": 1
  }
}</div>
    </div>

    <div class="card">
      <h3>4. Запрос отсутствующей задачи</h3>
      <div><b>GET /api/tasks/999</b> → <span class="badge-404">404 Not Found</span></div>
      <div class="json">{
  "error": {
    "code": "TASK_NOT_FOUND",
    "message": "Задача с id 999 не найдена.",
    "details": {
      "id": 999
    }
  }
}</div>
    </div>
  </div>
</body>
</html>`;

async function main() {
  await renderHtmlToPng(htmlTask1, "task1.html", "screenshot_task1.png");
  await renderHtmlToPng(htmlTask2, "task2.html", "screenshot_task2.png");
  await renderHtmlToPng(htmlTask3, "task3.html", "screenshot_task3.png");
  await renderHtmlToPng(htmlTask4, "task4.html", "screenshot_task4.png");
  console.log("All KR3 screenshots generated successfully!");
}

main().catch(console.error);
